This is the code for Adaptive Intelligence Assignment 1 2021.

Author : Maxime Fontana

2 Jupiter notebooks files are provided, they present different neural networks architectures, Perceptron.ipynb is used for a single-layer network, it is the file that should be used for up to question 4. It is the only file implementing the Weight Update Matrix as it was not needed later in the assignment.

The second file should be used from question 5 onwards, it implements the penalty and provides full flexibility in the layers' sizes and the number of neurons.

All results are replicable, feel free to tweak the hyper-parameters in the cell dedicated to constants.

Thank you.

